<?php
include 'components/header.php';
?>

<?php
include 'components/banner.php';
?>

<?php
include 'components/footer.php';
?>



    
