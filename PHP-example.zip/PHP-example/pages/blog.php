<?php
include '../components/header.php';
?>

<?php
include '../components2/blogbody.php';
?>


<?php
include '../components/footer.php';
?>